package com.project.services;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.project.entities.Product;
import com.project.helper.Excelhelper;
import com.project.repository.Productrepo;

@Service
public class ProductService {
	
	@Autowired
	private Productrepo productrepo;
	
	
	public void save(MultipartFile file ) {
		
		   try {
			List<Product>  produtcs = Excelhelper.ConvertingTheExcelFileToList(file.getInputStream());
			this.productrepo.saveAllAndFlush(produtcs);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public List<Product> getAllproducts(){
		
	  return this.productrepo.findAll();
		
	}

}
