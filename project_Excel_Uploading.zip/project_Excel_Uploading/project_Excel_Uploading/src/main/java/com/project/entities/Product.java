package com.project.entities;

import org.hibernate.annotations.GeneratorType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;


@Entity
@Data
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int hallticket;
	private String firstname;
	private String lastname;
	private String dob;
	private int Firstlanguage;
	private int Secondlanguage;
    private int thirdlanguage;
    private int mathematics;
    private int GeneralScience;
    private int social;
    private String ErrorMsg;
    
	

}
