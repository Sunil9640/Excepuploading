package com.project.helper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.project.entities.Product;

public class Excelhelper {
	
	public static boolean CheckExcelFormate(MultipartFile file) {
		String contentType = file.getContentType();
		if(contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
		{
			return true;
		}else {
			return false;
		}
		
	}

	public static List<Product> ConvertingTheExcelFileToList(InputStream is){
		
		List<Product> list =new ArrayList<>();
		try {
			
			// reading the data from the excel sheet
			
			XSSFWorkbook xssfWorkbook = new XSSFWorkbook(is);
			XSSFSheet sheet = xssfWorkbook.getSheet("Sheet1");   // getting the sheet with name
			 
			int rowNumber=0;
			 Iterator<Row> iterator = sheet.iterator();
			 while(iterator.hasNext()) {
				 Row row = iterator.next();
				 if(rowNumber==0) {
					 rowNumber++;
					 continue;
				 }
				 
				 Iterator<Cell> cells = row.iterator();
				 
				 int cid=0;
				 Product p=new Product();
				 
				 while(cells.hasNext()) {
					 Cell cell = cells.next();
					 
					 switch (cid) {
					 case 0:
						 p.setHallticket((int)cell.getNumericCellValue());
						 break;
					 case 1:
						 p.setFirstname(cell.getStringCellValue());
						 break;
					 case 2:
						 p.setLastname(cell.getStringCellValue());
						 break;
					 case 3:
						 p.setDob(cell.getStringCellValue());
						 break;
					 case 4:
						 p.setFirstlanguage((int)cell.getNumericCellValue());
						 break;
					 case 5:
						 p.setSecondlanguage((int)cell.getNumericCellValue());
						 break;
					 case 6:
						 p.setThirdlanguage((int)cell.getNumericCellValue());
						 break;
					 case 7:
						 p.setMathematics((int)cell.getNumericCellValue());
						 break;
					 case 8:
						 p.setGeneralScience((int)cell.getNumericCellValue());
						 break;
					 case 9:
						 p.setSocial((int)cell.getNumericCellValue());
						 break;
						 default:
							 break;
					 }
					 
					 cid++;
					 
				 }
				 
				 list.add(p);
			 }
			
		}catch (Exception e) {
		e.printStackTrace();
		}
		return list;
	}
	

	
}
